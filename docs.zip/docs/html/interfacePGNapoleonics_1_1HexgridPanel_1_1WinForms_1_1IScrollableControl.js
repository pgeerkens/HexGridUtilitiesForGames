var interfacePGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1IScrollableControl =
[
    [ "AutoScrollPosition", "interfacePGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1IScrollableControl.xhtml#af9fffaf7b578e19e04876a7c190138b4", null ],
    [ "ScrollLargeChange", "interfacePGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1IScrollableControl.xhtml#a6cc68983da61524c1e5f1205ef1f0b2a", null ],
    [ "UnappliedScroll", "interfacePGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1IScrollableControl.xhtml#a625f23c2e4a331be901a0e44e1a1c958", null ]
];