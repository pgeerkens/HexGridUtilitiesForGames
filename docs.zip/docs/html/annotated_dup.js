var annotated_dup =
[
    [ "PGNapoleonics", "namespacePGNapoleonics.xhtml", "namespacePGNapoleonics" ]
];