var interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves =
[
    [ "SetBestSoFar", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml#a3217c42da0699ff8d74d167b21175c2f", null ],
    [ "BestSoFar", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml#ab61055a7fcd8ee9af82fe1b589013699", null ],
    [ "Board", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml#a8aa2d3494e5d8c16a831b9c0b883a8b2", null ],
    [ "ClosedSet", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml#aeb320eb031f9f9b4ceaad0d329555196", null ],
    [ "Goal", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml#a0fca6f02be582d9520bcf503603388c1", null ],
    [ "Start", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml#a66cfe41f371515fc075cae4fb2ef7e22", null ]
];