var classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethods =
[
    [ "BitBlt", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethods.xhtml#acd6292a8306c71a1bdea89e72b29a2af", null ],
    [ "HiWord", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethods.xhtml#a84a882f39378731421e7af5954a84527", null ],
    [ "LoWord", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethods.xhtml#a04937e25d4dd3f0afe7f3486036b6674", null ],
    [ "SendMessage", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethods.xhtml#a3615abeb72ea53a769b70dd92d3fb9cd", null ],
    [ "WindowFromPoint", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethods.xhtml#a9ecd13e73fef2d09508a27a78c2e215f", null ]
];