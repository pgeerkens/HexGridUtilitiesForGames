var classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStack =
[
    [ "ImmutableStack", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStack.xhtml#adf658747093446f8fc755c609c432533", null ],
    [ "ImmutableStack", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStack.xhtml#a0e105d463546125eeeb6a92815e137df", null ],
    [ "GetEnumerator", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStack.xhtml#ac636db4e95bf89778453b3dd82f4a4bd", null ],
    [ "GetEnumerator", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStack.xhtml#aa05f16fe8f95b79e46b68f661376edb1", null ],
    [ "Push", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStack.xhtml#a71f9738e2df4ed2016f0b100f343b3a5", null ],
    [ "Remainder", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStack.xhtml#a96b876a409e5e898b89ad061e9982d01", null ],
    [ "TopItem", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStack.xhtml#a23b3e486487742125d327437e406d482", null ]
];