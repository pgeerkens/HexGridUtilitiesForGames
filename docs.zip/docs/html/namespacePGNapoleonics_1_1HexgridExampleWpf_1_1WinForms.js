var namespacePGNapoleonics_1_1HexgridExampleWpf_1_1WinForms =
[
    [ "NativeMethods", "classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods.xhtml", "classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods" ]
];