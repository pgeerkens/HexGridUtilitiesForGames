var interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf =
[
    [ "GetClipInHexes", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a6dc87346f752e305f3587faa99d34ba2", null ],
    [ "GetClipInHexes", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#af54b39c7c54f1cfac83dad9ded0438bf", null ],
    [ "PaintHighlight", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a1243252319f1ca7ebf50b26504e9ed71", null ],
    [ "PaintMap", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a037c7046b56086977491c43ecd44bd1c", null ],
    [ "PaintUnits", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a74937846067a7220b483633069354f59", null ],
    [ "BoardHexes", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a6173c2281a39dbdb54c0565694bbf494", null ],
    [ "FovRadius", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a01037497571671f598a62693d6e775be", null ],
    [ "GoalHex", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a93c760634abd0dfdea9cd83497676bb7", null ],
    [ "GridSize", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a18db2ac3ae381de5d66af2fd9be5b022", null ],
    [ "GridSizePixels", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a55e3572b65ef60da1041c765490c79ea", null ],
    [ "HotspotHex", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a6a540e24ff49e36a0e2a0105033fa564", null ],
    [ "IsTransposed", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a5e4afa80da858235cb5710f643c821c1", null ],
    [ "LandmarkToShow", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a6b53e687aa46ebb7051bae102eff2af4", null ],
    [ "MapScale", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#abbcb3dc64d5a1071b41c9a38a11f0b54", null ],
    [ "MapSizeHexes", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a18feb36292aa244476ae13cb98595b2b", null ],
    [ "Name", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a26c3f11ac4c560087678739376c609d8", null ],
    [ "Path", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a0c75969173abaf6844b2c114a981b966", null ],
    [ "StartHex", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a9505da8a5d6fc6ac70db7dea5857c273", null ]
];