var interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf =
[
    [ "GetClipInHexes", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a6dc87346f752e305f3587faa99d34ba2", null ],
    [ "GetClipInHexes", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#af54b39c7c54f1cfac83dad9ded0438bf", null ],
    [ "PaintHighlight", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a1243252319f1ca7ebf50b26504e9ed71", null ],
    [ "PaintMap", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a037c7046b56086977491c43ecd44bd1c", null ],
    [ "PaintUnits", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a74937846067a7220b483633069354f59", null ],
    [ "BoardHexes", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#acb29de3f73ab54b1135a6c928e227852", null ],
    [ "FovRadius", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#add6a2481d17a983e1eaed8070c61ee45", null ],
    [ "GoalHex", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#ada69c5605dcccde315ac4513152aaf4c", null ],
    [ "GridSize", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#ab6ff9f72766c9c750e63683f99091a8c", null ],
    [ "GridSizePixels", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a45096581c4e06a3ce37e93f4732172f3", null ],
    [ "HotspotHex", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a2c26d83fc5e2ab2732db818b1fb85723", null ],
    [ "IsTransposed", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a9a9a66e26788d97cf577035dde0fdfbc", null ],
    [ "LandmarkToShow", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a81c76c86f4b405d84e41f19892778e81", null ],
    [ "MapScale", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a888bfd0c17137b45b46b55f554d13c74", null ],
    [ "MapSizeHexes", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a64d137d7487e26e6be3a36ec1a2428c6", null ],
    [ "Name", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#add8e4634e074c0ecf786a8cbe141f434", null ],
    [ "Path", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a98816d4a12240f712e204e631c8ebda9", null ],
    [ "StartHex", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml#a6d10a5c358371835c2bce5ef0b7fbd94", null ]
];