var classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap =
[
    [ "TerrainMap", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap.xhtml#ac49447fb5fde524722d96d3c903d0a10", null ],
    [ "Heuristic", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap.xhtml#ac6eca09dc5a624eb3d721087722117e9", null ],
    [ "InitializeHex", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap.xhtml#a8a57f344595d1ac0c86a3367b9375900", null ],
    [ "_board", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap.xhtml#a9f684ad093a7edc0339e107c063bd1d6", null ],
    [ "_sizeHexes", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap.xhtml#a4437735713d3f74b315af8dc5463fb0a", null ],
    [ "ElevationBase", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap.xhtml#a2bd863463d1c782b3be41f3a8d0a9d8e", null ],
    [ "ElevationStep", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap.xhtml#a0813868b149b941fb955f684890a00a6", null ]
];