var structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords =
[
    [ "NeighbourCoords", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#a001cb3a62952345cbcfb7a5a738d19ca", null ],
    [ "Bind< T >", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#a54342269f4ec7784a5d748af526f65ac", null ],
    [ "Equals", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#a672ed5fcf16862c2279f914792fe7f35", null ],
    [ "Equals", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#ae0f4e572257019ec058996f4b4ad78ad", null ],
    [ "GetHashCode", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#add3257778b0f0ea72ddfc5b5a4d5a7d3", null ],
    [ "operator !=", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#aa229b3ed135f682c6819d3f6c446e505", null ],
    [ "operator==", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#a68ca24faf7fd8a914acb8c124d96aa42", null ],
    [ "ToString", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#a63d620b78b605c670a87e9d5c9c22b53", null ],
    [ "Coords", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#af85d4a99e80397e86edd0e7dbe07cec3", null ],
    [ "Hexside", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#ae31a90d46e022eb11787586d22a9b03c", null ]
];