var classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1WinFormsExtensions =
[
    [ "MakeDoubleBuffered", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1WinFormsExtensions.xhtml#ac6dc82420f9974129c6a3dc07564fc50", null ],
    [ "SetCompositedStyle", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1WinFormsExtensions.xhtml#abc498a046fdc929f984fa125147e3d81", null ]
];