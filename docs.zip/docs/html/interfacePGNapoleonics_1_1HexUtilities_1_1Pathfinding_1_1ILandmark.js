var interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmark =
[
    [ "DistanceFrom", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmark.xhtml#ae2612713d19e33dd70ef41052f750a28", null ],
    [ "DistanceTo", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmark.xhtml#ae4dd0bff6f6eb313e9c10efe10282b75", null ],
    [ "Coords", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmark.xhtml#a326b821d074741d1fbfb7f6bb56d1a91", null ]
];