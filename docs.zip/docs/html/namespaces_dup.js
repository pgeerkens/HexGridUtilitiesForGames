var namespaces_dup =
[
    [ "PGNapoleonics", "namespacePGNapoleonics.xhtml", "namespacePGNapoleonics" ]
];