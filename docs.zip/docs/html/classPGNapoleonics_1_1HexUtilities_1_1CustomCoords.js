var classPGNapoleonics_1_1HexUtilities_1_1CustomCoords =
[
    [ "CustomCoords", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#a25b551c0626b71a1d5101cfe60ddfca5", null ],
    [ "CustomCoords", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#a8e5b82caf44c0516f40906c1d80e062f", null ],
    [ "CustomToUser", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#a6917569294268ee2dc31d65d2a2ac1cc", null ],
    [ "Format", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#add1bb10bb3bcbee8e547694b94fe29c4", null ],
    [ "Format", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#ab8687ea1b44d9a54169a62f522adbfea", null ],
    [ "Format", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#a5ecd99d149df8a6eda9639c27725acc7", null ],
    [ "GetFormat", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#ad1f28bade451a36564bc0d38b31a0225", null ],
    [ "GetFormat", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#a969640787951dd04b87d115785455dc1", null ],
    [ "HandleOtherFormats", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#aec863ac2a46c89f6545adfb315784a49", null ],
    [ "UserToCustom", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#a9a2f6814a48cf8fadd651291295ca0dd", null ],
    [ "MatrixCustomToUser", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#af6e40ce4fa34e8d566fa6b467a200fff", null ],
    [ "MatrixUserToCustom", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml#ae90ff598cd6f6628a2155a5328c47cd6", null ]
];