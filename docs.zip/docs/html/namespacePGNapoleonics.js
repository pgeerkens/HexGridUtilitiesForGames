var namespacePGNapoleonics =
[
    [ "HexgridExampleCommon", "namespacePGNapoleonics_1_1HexgridExampleCommon.xhtml", "namespacePGNapoleonics_1_1HexgridExampleCommon" ],
    [ "HexgridExampleWinforms", "namespacePGNapoleonics_1_1HexgridExampleWinforms.xhtml", "namespacePGNapoleonics_1_1HexgridExampleWinforms" ],
    [ "HexgridExampleWinforms2", "namespacePGNapoleonics_1_1HexgridExampleWinforms2.xhtml", "namespacePGNapoleonics_1_1HexgridExampleWinforms2" ],
    [ "HexgridExampleWpf", "namespacePGNapoleonics_1_1HexgridExampleWpf.xhtml", "namespacePGNapoleonics_1_1HexgridExampleWpf" ],
    [ "HexgridPanel", "namespacePGNapoleonics_1_1HexgridPanel.xhtml", "namespacePGNapoleonics_1_1HexgridPanel" ],
    [ "HexUtilities", "namespacePGNapoleonics_1_1HexUtilities.xhtml", "namespacePGNapoleonics_1_1HexUtilities" ],
    [ "PGNapoleonics", "namespacePGNapoleonics_1_1PGNapoleonics.xhtml", null ],
    [ "WinForms", "namespacePGNapoleonics_1_1WinForms.xhtml", "namespacePGNapoleonics_1_1WinForms" ]
];