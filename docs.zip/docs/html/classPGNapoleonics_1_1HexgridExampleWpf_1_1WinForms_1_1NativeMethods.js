var classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods =
[
    [ "SendMessage", "classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods.xhtml#ad0402adda924904fb652f0e5e9266aa6", null ],
    [ "WindowFromPoint", "classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods.xhtml#acf00fab506893ff52e8953fe90103ce8", null ]
];