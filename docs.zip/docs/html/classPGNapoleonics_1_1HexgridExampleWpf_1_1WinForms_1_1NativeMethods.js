var classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods =
[
    [ "SendMessage", "classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods.xhtml#acb13a0dfa3c7c364c75a8474a5094dfc", null ],
    [ "WindowFromPoint", "classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods.xhtml#a53d8b054fde37329f2c5cbcc807dbbb1", null ]
];