var namespacePGNapoleonics_1_1HexgridExampleWpf =
[
    [ "Properties", "namespacePGNapoleonics_1_1HexgridExampleWpf_1_1Properties.xhtml", "namespacePGNapoleonics_1_1HexgridExampleWpf_1_1Properties" ],
    [ "App", "classPGNapoleonics_1_1HexgridExampleWpf_1_1App.xhtml", null ],
    [ "MainWindow", "classPGNapoleonics_1_1HexgridExampleWpf_1_1MainWindow.xhtml", "classPGNapoleonics_1_1HexgridExampleWpf_1_1MainWindow" ]
];