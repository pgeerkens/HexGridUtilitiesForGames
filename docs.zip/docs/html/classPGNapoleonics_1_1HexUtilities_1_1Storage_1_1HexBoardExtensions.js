var classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1HexBoardExtensions =
[
    [ "CentreOfHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1HexBoardExtensions.xhtml#aa9fdf39dae5a4710472456484b814276", null ],
    [ "ForEachHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1HexBoardExtensions.xhtml#ae37ccb8768c2fb54b7e829ae56104460", null ],
    [ "GetClipInHexes< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1HexBoardExtensions.xhtml#a918a914b38487defe4be455f0d166463", null ],
    [ "MapSizePixels< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1HexBoardExtensions.xhtml#a43fdbc987e8593d3bcc62f739de8d7d8", null ],
    [ "TranslateToHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1HexBoardExtensions.xhtml#a4a58fc793c2981ca4ad5c891168f48ff", null ],
    [ "UpperLeftOfHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1HexBoardExtensions.xhtml#af725f44f57aac14f555d1418c480e543", null ]
];