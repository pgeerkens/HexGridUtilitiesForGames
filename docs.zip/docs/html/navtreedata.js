/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "HexgridUtilitiesExamples", "index.xhtml", [
    [ "HexgridUtilities V 6.4", "index.xhtml", [
      [ "Introduction", "index.xhtml#Introduction", [
        [ "Detailed Description", "index.xhtml#Detailed_Description", null ],
        [ "Getting Started", "index.xhtml#Getting_Started", null ],
        [ "Authorship", "index.xhtml#Authorship", null ],
        [ "The MIT License:", "index.xhtml#The_MIT_License", null ]
      ] ]
    ] ],
    [ "Packages", "namespaces.xhtml", [
      [ "Packages", "namespaces.xhtml", "namespaces_dup" ],
      [ "Package Functions", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Functions", "namespacemembers_func.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ],
      [ "Class Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Class Members", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Properties", "functions_prop.xhtml", "functions_prop" ],
        [ "Events", "functions_evnt.xhtml", null ]
      ] ]
    ] ],
    [ "Files", "files.xhtml", [
      [ "File List", "files.xhtml", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"AStarBugMap_8cs_source.xhtml",
"classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml#abc1e1f609d17ab42997dbc6b0636d90e",
"classPGNapoleonics_1_1HexUtilities_1_1Common_1_1PointExtensions.xhtml#acf65ec9eb3b346c494cad159e15fdf8f",
"classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ConcurrentHashSet.xhtml#aa02164774b0aed3edf894ab662e26a9f",
"classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a34349d272182edba209e09b3de23aa63",
"classPGNapoleonics_1_1HexgridExampleWinforms_1_1MdiParent.xhtml#a7a2efd3db2b37b66d57b1ef2a9ca31ab",
"classPGNapoleonics_1_1HexgridPanel_1_1HexgridBufferedPanel.xhtml",
"classPGNapoleonics_1_1HexgridPanel_1_1MapPanel.xhtml#a0935123f1356f7257902c80c67996b12",
"classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1TransparentPanel.xhtml#a39d92930d00a153dcffbf47bc74502c9",
"interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathfinder.xhtml#a82f1f8b999add5129eae145edbebbf2a",
"structPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1FovCone.xhtml#a27086e10e0c94a5204de4678210642d5"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';