/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "HexgridUtilitiesExamples", "index.xhtml", [
    [ "HexgridUtilities V 6.4", "index.xhtml", [
      [ "Introduction", "index.xhtml#Introduction", [
        [ "Detailed Description", "index.xhtml#Detailed_Description", null ],
        [ "Getting Started", "index.xhtml#Getting_Started", null ],
        [ "Authorship", "index.xhtml#Authorship", null ],
        [ "The MIT License:", "index.xhtml#The_MIT_License", null ]
      ] ]
    ] ],
    [ "HexGridUtilitiesForGames", "md_README.xhtml", null ],
    [ "Packages", "namespaces.xhtml", [
      [ "Packages", "namespaces.xhtml", "namespaces_dup" ],
      [ "Package Functions", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Functions", "namespacemembers_func.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ],
      [ "Class Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Class Members", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Properties", "functions_prop.xhtml", "functions_prop" ],
        [ "Events", "functions_evnt.xhtml", null ]
      ] ]
    ] ],
    [ "Files", "files.xhtml", [
      [ "File List", "files.xhtml", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"AStarBugMap_8cs_source.xhtml",
"classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml#a5f0b755f372fc33d653bed1faef424c5",
"classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#abc9071a90a680949e157766a91c0daa1",
"classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ConcurrentHashSet.xhtml#a5f9dd1d410ce4cc32fd1119455e79f69",
"classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#ac0419b96c4670c5db53f6cf666b6ca58",
"classPGNapoleonics_1_1HexgridExampleWinforms_1_1MdiParent.xhtml#a5f3d37e14d02b42b7753e847a87fccdf",
"classPGNapoleonics_1_1HexgridPanel_1_1GraphicsExtensions.xhtml#ae71bb104398948346ed33278339be2cc",
"classPGNapoleonics_1_1HexgridPanel_1_1MapDisplayPainter.xhtml#af37d0f1bb230de34b96c7fde9145691d",
"classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1TiltAwareTreeView.xhtml#ab3155ae4a6af16a23e1287bc9991593f",
"interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1INavigableBoard.xhtml#a66d7a1301c81f2482b0724b7f0c5ecaf",
"structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Tracing.xhtml#adbfba7aedc580df8aee3a77163a60c64"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';