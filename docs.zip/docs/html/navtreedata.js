/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "HexgridUtilitiesExamples", "index.xhtml", [
    [ "HexgridUtilities V 6.4", "index.xhtml", [
      [ "Introduction", "index.xhtml#Introduction", [
        [ "Detailed Description", "index.xhtml#Detailed_Description", null ],
        [ "Getting Started", "index.xhtml#Getting_Started", null ],
        [ "Authorship", "index.xhtml#Authorship", null ],
        [ "The MIT License:", "index.xhtml#The_MIT_License", null ]
      ] ]
    ] ],
    [ "Packages", "namespaces.xhtml", [
      [ "Packages", "namespaces.xhtml", "namespaces_dup" ],
      [ "Package Functions", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Functions", "namespacemembers_func.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ],
      [ "Class Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Class Members", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Properties", "functions_prop.xhtml", "functions_prop" ],
        [ "Events", "functions_evnt.xhtml", null ]
      ] ]
    ] ],
    [ "Files", "files.xhtml", [
      [ "File List", "files.xhtml", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"AStarBugMap_8cs_source.xhtml",
"classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexExtensions.xhtml#add017ad6f7834503a5ed2cdffbcf07be",
"classPGNapoleonics_1_1HexUtilities_1_1Common_1_1SizeExtensions.xhtml#a37186c8f9bb355f6d06ea4480454c702",
"classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ConcurrentHashSet.xhtml#abc73a632051a1d87cccf4fe8013b73f5",
"classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a561e3ad731de1f318d02027e12b14700",
"classPGNapoleonics_1_1HexgridExampleWinforms_1_1MdiParent.xhtml#a7a2efd3db2b37b66d57b1ef2a9ca31ab",
"classPGNapoleonics_1_1HexgridPanel_1_1HexgridBufferedPanel.xhtml#a90ffbf3ab08ede0d426e3342cb42b2e0",
"classPGNapoleonics_1_1HexgridPanel_1_1MapPanel.xhtml#abc77de811836aed81007fcb33c8fd59c",
"functions_g.xhtml",
"namespacePGNapoleonics_1_1HexgridExampleWpf_1_1Properties.xhtml",
"structPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1DirectedPathStepHex.xhtml#a0d94509073f67e2da343e7c6542ae435"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';