/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "HexgridUtilitiesExamples", "index.xhtml", [
    [ "HexgridUtilities V 6.4", "index.xhtml", [
      [ "Introduction", "index.xhtml#Introduction", [
        [ "Detailed Description", "index.xhtml#Detailed_Description", null ],
        [ "Getting Started", "index.xhtml#Getting_Started", null ],
        [ "Authorship", "index.xhtml#Authorship", null ],
        [ "The MIT License:", "index.xhtml#The_MIT_License", null ]
      ] ]
    ] ],
    [ "HexGridUtilitiesForGames", "md_README.xhtml", null ],
    [ "Packages", "namespaces.xhtml", [
      [ "Packages", "namespaces.xhtml", "namespaces_dup" ],
      [ "Package Functions", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Functions", "namespacemembers_func.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ],
      [ "Class Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Class Members", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Properties", "functions_prop.xhtml", "functions_prop" ],
        [ "Events", "functions_evnt.xhtml", null ]
      ] ]
    ] ],
    [ "Files", "files.xhtml", [
      [ "File List", "files.xhtml", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"AStarBugMap_8cs_source.xhtml",
"classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MaybeExtensions.xhtml#aa8245e7389e5a9e505268c6b5f910947",
"classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ConcurrentHashSet.xhtml#aa02164774b0aed3edf894ab662e26a9f",
"classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a8c2f40a0d68db8e8b83156a8e71acd7e",
"classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1MapDisplayFlat.xhtml#acd0299268625a94167aacf2540125f61",
"classPGNapoleonics_1_1HexgridExampleWinforms_1_1MdiParent.xhtml#a7a2efd3db2b37b66d57b1ef2a9ca31ab",
"classPGNapoleonics_1_1HexgridPanel_1_1HexEventArgs.xhtml#aff23c5673efdd44f5af0fcf28eba7cb8",
"classPGNapoleonics_1_1HexgridPanel_1_1MapPanel.xhtml",
"classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1TransparentPanel.xhtml",
"interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplayWinForms.xhtml#a7f6507c0136504e16f7757ce7364011d",
"structPGNapoleonics_1_1HexUtilities_1_1IntMatrix2D.xhtml#a5fa1df9a32b93c936110a194b21b5bdc"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';