var classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1PaddingExtensions =
[
    [ "Offset", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1PaddingExtensions.xhtml#ad34bea0d513441e155f2e443559c2929", null ],
    [ "OffsetSize", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1PaddingExtensions.xhtml#acf7352154b8686316f092f0ab132e1ae", null ]
];