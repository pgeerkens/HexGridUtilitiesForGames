var classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EventArgs =
[
    [ "EventArgs", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EventArgs.xhtml#a617e17d7ddc9316ea62d13a02546d9d2", null ],
    [ "Value", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EventArgs.xhtml#a435c4eee677c9bc02e8e758fedd9888c", null ]
];