var searchData=
[
  ['unappliedscroll',['UnappliedScroll',['../interfacePGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1IScrollableControl.xhtml#a625f23c2e4a331be901a0e44e1a1c958',1,'PGNapoleonics.HexgridPanel.WinForms.IScrollableControl.UnappliedScroll()'],['../classPGNapoleonics_1_1HexgridPanel_1_1TiltAwareScrollableControl.xhtml#ab4f3f22d494c59a9a67c07983371684a',1,'PGNapoleonics.HexgridPanel.TiltAwareScrollableControl.UnappliedScroll()']]],
  ['usemetric',['UseMetric',['../classPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1ShadowCasting.xhtml#aa3b4a403e98691ebbf503d0a76261ea2',1,'PGNapoleonics::HexUtilities::FieldOfView::ShadowCasting']]],
  ['user',['User',['../structPGNapoleonics_1_1HexUtilities_1_1HexCoords.xhtml#aa139e9184147a9c9c67976e57344b961',1,'PGNapoleonics::HexUtilities::HexCoords']]]
];
