var searchData=
[
  ['scalechange',['ScaleChange',['../classPGNapoleonics_1_1HexgridPanel_1_1HexgridPanel.xhtml#a67fa90d22f5b7698ea30f08ccfbf4586',1,'PGNapoleonics.HexgridPanel.HexgridPanel.ScaleChange()'],['../classPGNapoleonics_1_1HexgridPanel_1_1HexgridViewModel.xhtml#a4055e4514c3adfe77d9dc72efc518b69',1,'PGNapoleonics.HexgridPanel.HexgridViewModel.ScaleChange()']]]
];
