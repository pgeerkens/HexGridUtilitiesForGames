var searchData=
[
  ['datacontext',['DataContext',['../classPGNapoleonics_1_1HexgridPanel_1_1HexgridPanel.xhtml#a30a4248f15235caebab47aa83970bfc6',1,'PGNapoleonics::HexgridPanel::HexgridPanel']]],
  ['displayname',['DisplayName',['../classPGNapoleonics_1_1HexgridPanel_1_1ViewModelBase.xhtml#a81d45ae0ab6bcf502a3adad202a59254',1,'PGNapoleonics.HexgridPanel.ViewModelBase.DisplayName()'],['../classPGNapoleonics_1_1HexgridExampleWinforms2_1_1ViewModelBase.xhtml#a4ef950acb53e551bbcd6069bea92f0e7',1,'PGNapoleonics.HexgridExampleWinforms2.ViewModelBase.DisplayName()']]]
];
