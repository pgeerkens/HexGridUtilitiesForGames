var searchData=
[
  ['location',['Location',['../structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#ac8fb8188b5bcf10de1d27749f2de5f2c',1,'PGNapoleonics::HexUtilities::Common::CoordsRectangle']]]
];
