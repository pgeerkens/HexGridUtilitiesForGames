var searchData=
[
  ['querydragicon',['QueryDragIcon',['../namespacePGNapoleonics_1_1HexgridPanel_1_1WinForms.xhtml#a69c304e086a6c28cf9f8638c19a520daaf4dee044a54e29b7a318ef0c18adf029',1,'PGNapoleonics::HexgridPanel::WinForms']]],
  ['queryendsession',['QueryEndSession',['../namespacePGNapoleonics_1_1HexgridPanel_1_1WinForms.xhtml#a69c304e086a6c28cf9f8638c19a520daa2fff2b16bd73d30c52139a033e214f53',1,'PGNapoleonics::HexgridPanel::WinForms']]],
  ['querynewpalette',['QueryNewPalette',['../namespacePGNapoleonics_1_1HexgridPanel_1_1WinForms.xhtml#a69c304e086a6c28cf9f8638c19a520daa963e18b859b9b8b170959f80cdb1887b',1,'PGNapoleonics::HexgridPanel::WinForms']]],
  ['queryopen',['QueryOpen',['../namespacePGNapoleonics_1_1HexgridPanel_1_1WinForms.xhtml#a69c304e086a6c28cf9f8638c19a520daabad88a4259ff7a852dc98a3ab3d2ec29',1,'PGNapoleonics::HexgridPanel::WinForms']]],
  ['queryuistate',['QueryUiState',['../namespacePGNapoleonics_1_1HexgridPanel_1_1WinForms.xhtml#a69c304e086a6c28cf9f8638c19a520daa48366f59d0c6dcff377c2c88039fdc5b',1,'PGNapoleonics::HexgridPanel::WinForms']]],
  ['queuesync',['QueueSync',['../namespacePGNapoleonics_1_1HexgridPanel_1_1WinForms.xhtml#a69c304e086a6c28cf9f8638c19a520daacbb3f94e1d812fb7bead04f0011e559a',1,'PGNapoleonics::HexgridPanel::WinForms']]],
  ['quit',['Quit',['../namespacePGNapoleonics_1_1HexgridPanel_1_1WinForms.xhtml#a69c304e086a6c28cf9f8638c19a520daa0d82790b0612935992bd564a17ce37d6',1,'PGNapoleonics::HexgridPanel::WinForms']]]
];
