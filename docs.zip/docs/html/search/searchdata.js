var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxyz~",
  1: "abcdefghilmnprstvw",
  2: "p",
  3: "abcdefghilmnopqrstuvwx~",
  4: "_abcdefghiklmnpstv",
  5: "dfhmsw",
  6: "acdefghiklmnopqrstuvwxz",
  7: "abcdefghiklmnoprstuvwxy",
  8: "hlmprs",
  9: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events",
  9: "Pages"
};

