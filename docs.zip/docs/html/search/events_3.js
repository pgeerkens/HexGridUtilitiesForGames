var searchData=
[
  ['propertychanged',['PropertyChanged',['../classPGNapoleonics_1_1HexgridExampleWinforms2_1_1ViewModelBase.xhtml#a96aa71e328752cdb69f6e6a208aacdec',1,'PGNapoleonics.HexgridExampleWinforms2.ViewModelBase.PropertyChanged()'],['../classPGNapoleonics_1_1HexgridPanel_1_1ViewModelBase.xhtml#a906267982b63eddae1b53ea7f181c249',1,'PGNapoleonics.HexgridPanel.ViewModelBase.PropertyChanged()']]]
];
