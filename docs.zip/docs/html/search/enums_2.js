var searchData=
[
  ['hexsides',['Hexsides',['../namespacePGNapoleonics_1_1HexUtilities.xhtml#afc961f4762b47d84dd82d8c136078fd5',1,'PGNapoleonics::HexUtilities']]]
];
