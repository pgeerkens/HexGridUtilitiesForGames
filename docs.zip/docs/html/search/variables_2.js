var searchData=
[
  ['blockmask',['BlockMask',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage32x32.xhtml#a2ee5bb5a4884dc25cbac46963d3cfc91',1,'PGNapoleonics::HexUtilities::Storage::BlockedBoardStorage32x32']]],
  ['blockside',['BlockSide',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage32x32.xhtml#a351fd8c537b31d9c0de6ec1e0a68441a',1,'PGNapoleonics::HexUtilities::Storage::BlockedBoardStorage32x32']]]
];
