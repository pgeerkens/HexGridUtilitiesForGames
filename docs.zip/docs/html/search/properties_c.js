var searchData=
[
  ['name',['Name',['../classPGNapoleonics_1_1HexUtilities_1_1Hexside.xhtml#aeaa9dae95eef95ee34ed3e4d7fd73687',1,'PGNapoleonics.HexUtilities.Hexside.Name()'],['../interfacePGNapoleonics_1_1HexUtilities_1_1IMapDisplay.xhtml#a26c3f11ac4c560087678739376c609d8',1,'PGNapoleonics.HexUtilities.IMapDisplay.Name()']]],
  ['nullthreadexceptionargs',['NullThreadExceptionArgs',['../classPGNapoleonics_1_1HexgridPanel_1_1Properties_1_1Resources.xhtml#a557b11f257e6b97e80c7370bc13ded72',1,'PGNapoleonics::HexgridPanel::Properties::Resources']]],
  ['nulsender',['NulSender',['../classPGNapoleonics_1_1HexgridPanel_1_1Properties_1_1Resources.xhtml#ad9db85b93916eb3e498a56c19e4a9c6d',1,'PGNapoleonics::HexgridPanel::Properties::Resources']]]
];
