var searchData=
[
  ['fontchange',['FontChange',['../namespacePGNapoleonics_1_1HexgridPanel_1_1WinForms.xhtml#a69c304e086a6c28cf9f8638c19a520daabc7590d2e2171fe66a533a1346d3da25',1,'PGNapoleonics::HexgridPanel::WinForms']]]
];
