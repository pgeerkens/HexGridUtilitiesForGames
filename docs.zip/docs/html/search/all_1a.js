var searchData=
[
  ['_7eboardstorage',['~BoardStorage',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a6110b3edb5574d43ebf078bc28896902',1,'PGNapoleonics::HexUtilities::Storage::BoardStorage']]],
  ['_7eviewmodelbase',['~ViewModelBase',['../classPGNapoleonics_1_1HexgridPanel_1_1ViewModelBase.xhtml#a330a5892c3908780cdd85ad582836e8e',1,'PGNapoleonics.HexgridPanel.ViewModelBase.~ViewModelBase()'],['../classPGNapoleonics_1_1HexgridExampleWinforms2_1_1ViewModelBase.xhtml#afb9f8de375fd2b1ce8736f0ce521fc0a',1,'PGNapoleonics.HexgridExampleWinforms2.ViewModelBase.~ViewModelBase()']]]
];
