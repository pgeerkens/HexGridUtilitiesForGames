var searchData=
[
  ['background',['Background',['../classPGNapoleonics_1_1HexgridPanel_1_1Layer.xhtml#a0ed15571ba70221570061d9211dcb0ad',1,'PGNapoleonics::HexgridPanel::Layer']]],
  ['bestsofar',['BestSoFar',['../interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml#ab61055a7fcd8ee9af82fe1b589013699',1,'PGNapoleonics.HexUtilities.Pathfinding.IPathHalves.BestSoFar()'],['../classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PathHalves.xhtml#a3e2534217420e39ad9be5f9163e2668b',1,'PGNapoleonics.HexUtilities.Pathfinding.PathHalves.BestSoFar()']]],
  ['blockmask',['BlockMask',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage.xhtml#a23c44f9bd006b5a480b145a64f4d4342',1,'PGNapoleonics::HexUtilities::Storage::BlockedBoardStorage']]],
  ['blockside',['BlockSide',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage.xhtml#a6eb75f8189e22224013eda8e74e91de2',1,'PGNapoleonics::HexUtilities::Storage::BlockedBoardStorage']]],
  ['board',['Board',['../interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml#a8aa2d3494e5d8c16a831b9c0b883a8b2',1,'PGNapoleonics.HexUtilities.Pathfinding.IPathHalves.Board()'],['../classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PathHalves.xhtml#a7952fd94e1b49893b901848f53205169',1,'PGNapoleonics.HexUtilities.Pathfinding.PathHalves.Board()']]],
  ['boardhexes',['BoardHexes',['../classPGNapoleonics_1_1HexUtilities_1_1HexBoard.xhtml#a1f73bb9825789b81394630c57fadbae1',1,'PGNapoleonics.HexUtilities.HexBoard.BoardHexes()'],['../interfacePGNapoleonics_1_1HexUtilities_1_1IMapDisplay.xhtml#a6173c2281a39dbdb54c0565694bbf494',1,'PGNapoleonics.HexUtilities.IMapDisplay.BoardHexes()']]],
  ['buffer',['Buffer',['../classPGNapoleonics_1_1HexgridPanel_1_1Layer.xhtml#aece0d7158e2db85d7efa6cefb2139186',1,'PGNapoleonics::HexgridPanel::Layer']]]
];
