var searchData=
[
  ['zerodegrees',['ZeroDegrees',['../namespacePGNapoleonics_1_1HexgridPanel.xhtml#a6ca83c66bec9a3fe35333bfa6d78677dad833129a5b64e628b3f6bb6a1e6bfde2',1,'PGNapoleonics::HexgridPanel']]]
];
