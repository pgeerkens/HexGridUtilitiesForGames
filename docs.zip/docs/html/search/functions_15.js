var searchData=
[
  ['xor',['Xor',['../structPGNapoleonics_1_1HexUtilities_1_1IntVector2D.xhtml#a731c00076bf5d222f4d95903e686db51',1,'PGNapoleonics::HexUtilities::IntVector2D']]]
];
