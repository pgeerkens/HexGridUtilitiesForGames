var searchData=
[
  ['astarbugmapdefinition',['AStarBugMapDefinition',['../classPGNapoleonics_1_1HexgridExampleCommon_1_1MapDefinitions.xhtml#a42014434896fd78d6b1d75b4ee6dbd16',1,'PGNapoleonics::HexgridExampleCommon::MapDefinitions']]]
];
