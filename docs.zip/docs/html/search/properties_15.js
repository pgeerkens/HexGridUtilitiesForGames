var searchData=
[
  ['x',['X',['../structPGNapoleonics_1_1HexUtilities_1_1IntVector2D.xhtml#a2738cdf0d9a45bd481c48a2c4dbfdaa2',1,'PGNapoleonics::HexUtilities::IntVector2D']]]
];
