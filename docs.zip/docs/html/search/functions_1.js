var searchData=
[
  ['backingstore',['BackingStore',['../classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1Landmark.xhtml#a2045564aee7ab2f4e2ce1c6f0f6da92b',1,'PGNapoleonics::HexUtilities::Pathfinding::Landmark']]],
  ['begininit',['BeginInit',['../classPGNapoleonics_1_1HexgridPanel_1_1HexgridPanel.xhtml#a18de387345e61fe604a74822000f9fd9',1,'PGNapoleonics.HexgridPanel.HexgridPanel.BeginInit()'],['../classPGNapoleonics_1_1HexgridPanel_1_1LayeredScrollable.xhtml#aa8ce2c16abdfe919b7efa2f38bcec2d3',1,'PGNapoleonics.HexgridPanel.LayeredScrollable.BeginInit()']]],
  ['bidirectionalaltpathfinder',['BidirectionalAltPathfinder',['../classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1BidirectionalAltPathfinder.xhtml#a72bfd7b12f0f8d1e9017773e7245d6ba',1,'PGNapoleonics::HexUtilities::Pathfinding::BidirectionalAltPathfinder']]],
  ['bind_3c_20t_20_3e',['Bind&lt; T &gt;',['../structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml#a54342269f4ec7784a5d748af526f65ac',1,'PGNapoleonics::HexUtilities::NeighbourCoords']]],
  ['bind_3c_20tout_20_3e',['Bind&lt; TOut &gt;',['../structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Maybe.xhtml#a0b119e6e1f5d68526cfb51bceff87d1c',1,'PGNapoleonics::HexUtilities::Common::Maybe']]],
  ['bind_3c_20tvalue_2c_20tresult_20_3e',['Bind&lt; TValue, TResult &gt;',['../classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#ab56178b4aba1103bcab8353d0783e2a9',1,'PGNapoleonics::HexUtilities::Common::NullableExtensions']]],
  ['bitblt',['BitBlt',['../classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethods.xhtml#acd6292a8306c71a1bdea89e72b29a2af',1,'PGNapoleonics::HexgridPanel::WinForms::NativeMethods']]],
  ['bitcount',['BitCount',['../classPGNapoleonics_1_1HexUtilities_1_1HexsidesExtensions.xhtml#a1b146ca8c4899251650b31c6cbc28a31',1,'PGNapoleonics::HexUtilities::HexsidesExtensions']]],
  ['bitwiseand',['BitwiseAnd',['../structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Tracing.xhtml#ad76d6303101a690761f995757cff6772',1,'PGNapoleonics::HexUtilities::Common::Tracing']]],
  ['bitwiseor',['BitwiseOr',['../structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Tracing.xhtml#af99b5bd673c89f80c05549be6ae73c12',1,'PGNapoleonics::HexUtilities::Common::Tracing']]],
  ['blockedboardstorage',['BlockedBoardStorage',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage.xhtml#a7d1c0a9e0f334055729f4c13be59068d',1,'PGNapoleonics::HexUtilities::Storage::BlockedBoardStorage']]],
  ['blockedboardstorage32x32',['BlockedBoardStorage32x32',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage32x32.xhtml#a797b0b5ff184bfdb56767624203181fc',1,'PGNapoleonics::HexUtilities::Storage::BlockedBoardStorage32x32']]],
  ['boardstorage',['BoardStorage',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a221471d003f562b7acabfe6d76fa02e5',1,'PGNapoleonics::HexUtilities::Storage::BoardStorage']]]
];
