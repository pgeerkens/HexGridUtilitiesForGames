var searchData=
[
  ['bidirectionalaltpathfinder',['BidirectionalAltPathfinder',['../classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1BidirectionalAltPathfinder.xhtml',1,'PGNapoleonics::HexUtilities::Pathfinding']]],
  ['bitmapextensions',['BitmapExtensions',['../classPGNapoleonics_1_1HexgridPanel_1_1BitmapExtensions.xhtml',1,'PGNapoleonics::HexgridPanel']]],
  ['blockedboardstorage',['BlockedBoardStorage',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage.xhtml',1,'PGNapoleonics::HexUtilities::Storage']]],
  ['blockedboardstorage32x32',['BlockedBoardStorage32x32',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage32x32.xhtml',1,'PGNapoleonics::HexUtilities::Storage']]],
  ['boardstorage',['BoardStorage',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml',1,'PGNapoleonics::HexUtilities::Storage']]],
  ['boardstorage_3c_20maybe_3c_20thex_20_3e_20_3e',['BoardStorage&lt; Maybe&lt; THex &gt; &gt;',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml',1,'PGNapoleonics::HexUtilities::Storage']]],
  ['boardstorage_3c_20short_3f_3e',['BoardStorage&lt; short?&gt;',['../classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml',1,'PGNapoleonics::HexUtilities::Storage']]],
  ['bufferedgraphicsextensions',['BufferedGraphicsExtensions',['../classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1BufferedGraphicsExtensions.xhtml',1,'PGNapoleonics::HexgridPanel::WinForms']]]
];
