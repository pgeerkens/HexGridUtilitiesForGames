var searchData=
[
  ['direction',['Direction',['../namespacePGNapoleonics_1_1HexUtilities_1_1Pathfinding.xhtml#ad0d97aa056644ab4c023b96e22ea0773',1,'PGNapoleonics::HexUtilities::Pathfinding']]]
];
