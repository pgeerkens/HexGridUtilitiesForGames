var searchData=
[
  ['requestclose',['RequestClose',['../classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#ab89f98df3d81ecd6e50c772e7a9cbd19',1,'PGNapoleonics.HexgridPanel.WorkspaceViewModel.RequestClose()'],['../classPGNapoleonics_1_1HexgridExampleWinforms2_1_1WorkspaceViewModel.xhtml#a234c87b165f5a8499c6c7ff9a4d37feb',1,'PGNapoleonics.HexgridExampleWinforms2.WorkspaceViewModel.RequestClose()']]]
];
