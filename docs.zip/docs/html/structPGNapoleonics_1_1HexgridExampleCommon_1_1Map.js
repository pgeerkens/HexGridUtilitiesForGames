var structPGNapoleonics_1_1HexgridExampleCommon_1_1Map =
[
    [ "Map", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#a5f9d342d290ad0869c39fdfa50af7239", null ],
    [ "Equals", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#ad78aa1761d29ac6b2608b75904ee62cb", null ],
    [ "Equals", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#affbc16ce2daa6456671b7b25a4738f81", null ],
    [ "GetHashCode", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#a153bcc9351b890558d43145477857001", null ],
    [ "operator !=", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#ac1a731266a5ee302c6b730977090d746", null ],
    [ "operator==", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#a58cfc475c66ab79f91eec70366ad9e8f", null ],
    [ "MapBoard", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#ace830d96a1e28558cd5b6ad3e7316acd", null ],
    [ "MapList", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#a08c73afe83007a67a548576a324593c8", null ],
    [ "MapName", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#a37a55c547a1ec5fbe112efa4b918aee7", null ],
    [ "MapSource", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml#a8bb841723cf7e8ff64d780318ddd37de", null ]
];