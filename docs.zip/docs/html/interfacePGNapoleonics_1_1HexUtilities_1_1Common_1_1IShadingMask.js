var interfacePGNapoleonics_1_1HexUtilities_1_1Common_1_1IShadingMask =
[
    [ "this[HexCoords coords]", "interfacePGNapoleonics_1_1HexUtilities_1_1Common_1_1IShadingMask.xhtml#a391c66e97e0c296ad0ce22dcc50bca33", null ]
];