var interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage =
[
    [ "ForAllNeighbours", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage.xhtml#a57a8599ba45f6e7f142ec17f724d32a2", null ],
    [ "Neighbour", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage.xhtml#a2135897bca5f71fbd44c2caf0064b2af", null ],
    [ "MapSizeHexes", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage.xhtml#ab6aa2a29bb8f6e582afba6258bd8acc6", null ],
    [ "this[HexCoords coords]", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage.xhtml#a28806b85d0a0a6b753852efdabf93693", null ]
];