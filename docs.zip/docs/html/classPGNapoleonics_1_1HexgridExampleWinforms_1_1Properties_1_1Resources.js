var classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources =
[
    [ "Resources", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources.xhtml#a482a83ad6f50083c4107ae7e11124425", null ],
    [ "resourceCulture", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources.xhtml#a45ab5df59ef94ec1b4eceba60ecea195", null ],
    [ "resourceMan", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources.xhtml#ab6983eebc96495bd499b5213a7ac9f56", null ],
    [ "Culture", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources.xhtml#acb976e2e7c6ea60194b36c2e3f464bd2", null ],
    [ "FileExtensionMask", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources.xhtml#a66401d0d8ac0fe82452406ce39d1d2da", null ],
    [ "ResourceManager", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources.xhtml#a649fcc4d1b2ab39b071767bc4f154fe5", null ],
    [ "StatusLabelText", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources.xhtml#ade9e2e1b0d6078a91e689cb36f899057", null ]
];