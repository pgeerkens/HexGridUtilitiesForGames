var classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel =
[
    [ "WorkspaceViewModel", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#abb392c63a208c074cacb63498999d278", null ],
    [ "WorkspaceViewModel", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#a7d93fc9a19903bd733143f4f09a2a25a", null ],
    [ "Dispose", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#a8fb72bb4d33cad2e96c966836c1b5726", null ],
    [ "Dispose", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#a1585c919a5d65c14959ffe067dd27329", null ],
    [ "OnPropertyChanged", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#a2a1e268e45c199b424b782ee6bb6cc69", null ],
    [ "OnRequestClose", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#aaf780192a7496e01799e2bfad1e9aa3a", null ],
    [ "VerifyPropertyName", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#a64bde71257cf194bfb8beeda104ca2fc", null ],
    [ "CloseCommand", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#af4b08043930886102d35c17f0716f54d", null ],
    [ "DisplayName", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#a81d45ae0ab6bcf502a3adad202a59254", null ],
    [ "ThrowOnInvalidPropertyName", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#a6e6295db0f6ae71338d3a77f18d6615e", null ],
    [ "PropertyChanged", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#a906267982b63eddae1b53ea7f181c249", null ],
    [ "RequestClose", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml#ab89f98df3d81ecd6e50c772e7a9cbd19", null ]
];