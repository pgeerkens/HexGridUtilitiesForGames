var classPGNapoleonics_1_1HexgridExampleWpf_1_1Properties_1_1Resources =
[
    [ "Resources", "classPGNapoleonics_1_1HexgridExampleWpf_1_1Properties_1_1Resources.xhtml#ad39d3172511ecaa70a89cc16c9cc4254", null ],
    [ "resourceCulture", "classPGNapoleonics_1_1HexgridExampleWpf_1_1Properties_1_1Resources.xhtml#a3235b21f2ebd03bd0ee7c6256d6bf1eb", null ],
    [ "resourceMan", "classPGNapoleonics_1_1HexgridExampleWpf_1_1Properties_1_1Resources.xhtml#a263de5bcff79545599350fd67f3e99fc", null ],
    [ "Culture", "classPGNapoleonics_1_1HexgridExampleWpf_1_1Properties_1_1Resources.xhtml#a256746966c78252b0ed51b4d8404e1a3", null ],
    [ "ResourceManager", "classPGNapoleonics_1_1HexgridExampleWpf_1_1Properties_1_1Resources.xhtml#a86d1725ef55b615ce911d324df6ece8b", null ]
];