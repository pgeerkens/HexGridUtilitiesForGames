var classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayExtensions =
[
    [ "CentreOfHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayExtensions.xhtml#acad5064f1335ae6122368a4d24cf7ca0", null ],
    [ "TranslateToHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayExtensions.xhtml#ab7694ccfc9932878fb551e8b23d69eaf", null ],
    [ "UpperLeftOfHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayExtensions.xhtml#af52d75231c0ad3fa46471a48c989330f", null ]
];