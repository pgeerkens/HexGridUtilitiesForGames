var classPGNapoleonics_1_1HexgridExampleCommon_1_1Properties_1_1Resources =
[
    [ "Resources", "classPGNapoleonics_1_1HexgridExampleCommon_1_1Properties_1_1Resources.xhtml#ac4881ccf16bb977ce99ea05d9aa82593", null ],
    [ "resourceCulture", "classPGNapoleonics_1_1HexgridExampleCommon_1_1Properties_1_1Resources.xhtml#a1edeb3c9f6a103ec6d37efdb5aed18fb", null ],
    [ "resourceMan", "classPGNapoleonics_1_1HexgridExampleCommon_1_1Properties_1_1Resources.xhtml#a01e89606e028e37ce891a295b5876137", null ],
    [ "Culture", "classPGNapoleonics_1_1HexgridExampleCommon_1_1Properties_1_1Resources.xhtml#a6225d8db0aadaab5e4f0f03a4c220e6f", null ],
    [ "ResourceManager", "classPGNapoleonics_1_1HexgridExampleCommon_1_1Properties_1_1Resources.xhtml#a796b989bc597eb86639d939222b86488", null ],
    [ "StatusLabelText", "classPGNapoleonics_1_1HexgridExampleCommon_1_1Properties_1_1Resources.xhtml#adb8e16e6817ad7fe35f7f70b06c178a6", null ]
];