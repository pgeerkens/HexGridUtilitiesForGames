var namespacePGNapoleonics_1_1HexUtilities_1_1Common =
[
    [ "EnumExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EnumExtensions.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EnumExtensions" ],
    [ "EnumHelper", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EnumHelper.xhtml", null ],
    [ "EventArgs", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EventArgs.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EventArgs" ],
    [ "Extensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions" ],
    [ "HexExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexExtensions.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexExtensions" ],
    [ "ImmutableStackCollection", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection" ],
    [ "IShadingMask", "interfacePGNapoleonics_1_1HexUtilities_1_1Common_1_1IShadingMask.xhtml", "interfacePGNapoleonics_1_1HexUtilities_1_1Common_1_1IShadingMask" ],
    [ "Maybe", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Maybe.xhtml", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Maybe" ],
    [ "MaybeExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MaybeExtensions.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MaybeExtensions" ],
    [ "NullableExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions" ],
    [ "Tracing", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Tracing.xhtml", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Tracing" ],
    [ "ValueChangedEventArgs", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ValueChangedEventArgs.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ValueChangedEventArgs" ]
];