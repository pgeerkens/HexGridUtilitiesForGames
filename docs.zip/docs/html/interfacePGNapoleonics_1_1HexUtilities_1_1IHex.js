var interfacePGNapoleonics_1_1HexUtilities_1_1IHex =
[
    [ "HeightHexside", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml#ab96ced84e8ea7886a768632d29fd6323", null ],
    [ "TryStepCost", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml#a3a09bc115a2a78d7f44b8e2ea182e950", null ],
    [ "Coords", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml#a7201dd51930718ef1b5f135c941f8ff3", null ],
    [ "ElevationLevel", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml#af8caf52d8df8d9f5be27be17b06c3e03", null ],
    [ "HeightObserver", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml#a1888d083417398936663404ec3ae9b76", null ],
    [ "HeightTarget", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml#a8e84d7ccb5d0529b77c0988249a97b29", null ],
    [ "HeightTerrain", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml#a15bdac96e8edab0e13bb255ec8f4f0bf", null ],
    [ "TerrainType", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml#ae6dc735bd12cbcac3fee7eca2632f85e", null ]
];