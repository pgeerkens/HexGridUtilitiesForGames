var namespacePGNapoleonics_1_1HexgridExampleWinforms =
[
    [ "Properties", "namespacePGNapoleonics_1_1HexgridExampleWinforms_1_1Properties.xhtml", "namespacePGNapoleonics_1_1HexgridExampleWinforms_1_1Properties" ],
    [ "MdiParent", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1MdiParent.xhtml", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1MdiParent" ]
];