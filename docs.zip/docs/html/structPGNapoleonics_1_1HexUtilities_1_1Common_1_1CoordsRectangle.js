var structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle =
[
    [ "EncompassesHex", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#a1f2a186c6766869c488afaa14d319eb8", null ],
    [ "Equals", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#af3434511ada8d12f983aa05742154cad", null ],
    [ "Equals", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#a8969f028c090409bcbce86f283391dca", null ],
    [ "GetHashCode", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#a7dd7ab93635bd4c52af6a50221aca1ab", null ],
    [ "New", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#a42fb748357c75af99f3c9c3a6513f757", null ],
    [ "New", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#aa7fd29e3108c6998fc5f39d7620967ec", null ],
    [ "operator !=", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#afa022b2eae0046aad97b817d2ddba88d", null ],
    [ "operator CoordsRectangle", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#a0dfc0c5d6ba3b3c548dd1772ec67777a", null ],
    [ "operator HexRectangle", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#a3d2413e4b07df7807815231740e659e3", null ],
    [ "operator==", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#ac6e17dd3d6adba6cbb863882c88f2ae8", null ],
    [ "ToString", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#ac127ba31dd4d1d0ca9353bf377fd7d91", null ],
    [ "Location", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#ac8fb8188b5bcf10de1d27749f2de5f2c", null ],
    [ "Size", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#af441cb663c94a357c200908a59170146", null ],
    [ "Rectangle", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml#af38baa8c988a4627f26429ca62138be7", null ]
];