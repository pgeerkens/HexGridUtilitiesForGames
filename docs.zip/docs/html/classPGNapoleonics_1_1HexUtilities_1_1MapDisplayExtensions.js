var classPGNapoleonics_1_1HexUtilities_1_1MapDisplayExtensions =
[
    [ "MapSizePixels< THex >", "classPGNapoleonics_1_1HexUtilities_1_1MapDisplayExtensions.xhtml#abd11446cdaab37e11fa21c255bcdc0f5", null ]
];