var classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions =
[
    [ "InitializeDisposable< T >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions.xhtml#affa4477013178a01f481e150f04b400c", null ],
    [ "InRange", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions.xhtml#a4d3b233e92be04c8060edd0de96b3d5c", null ],
    [ "IsOnboard", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions.xhtml#a1fea894992aedc478cce0bea9532cc4e", null ],
    [ "IsOnboard", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions.xhtml#a35c47605ebfdfe7e72a14735861833d6", null ],
    [ "IsOnboard", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions.xhtml#a0783e23a97936948b68e252ed58967cd", null ],
    [ "Modulo", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions.xhtml#a54daa44c39bca831a2618bbcf220f56d", null ]
];