var classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PriorityQueueFactory =
[
    [ "NewDictionaryQueue< TPriority, TValue >", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PriorityQueueFactory.xhtml#abd558001f91cb967dd2530f8bc291113", null ],
    [ "NewHotPriorityQueue< TValue >", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PriorityQueueFactory.xhtml#a5cc45e887ab299281f977092e630981f", null ],
    [ "NewHotPriorityQueue< TValue >", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PriorityQueueFactory.xhtml#aebe3073421a2e5a336d1e931e1ea978f", null ]
];