var classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage =
[
    [ "FlatBoardStorage", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a0b11926fd17afdd52314eeeda06300b8", null ],
    [ "Dispose", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#ae931e3379e95fa80dfb90b79dbae7b67", null ],
    [ "Dispose", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a2867e0c9f0067428396fc58424275ecb", null ],
    [ "ForAllNeighbours", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a1f9f40b03390e77ce943b179049ff813", null ],
    [ "ForEach", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a18dfcb53b98e71c70b189a697726b8db", null ],
    [ "ForEach", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a07fb113679908495bfaffe1e0188b3f1", null ],
    [ "ForEach", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#aea5c43ecc6663ce888bb939bcbb7d40e", null ],
    [ "ForEach", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a561e3ad731de1f318d02027e12b14700", null ],
    [ "ForEachSerial", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#aed9eba57373a4b6f04cc4b8d515824ff", null ],
    [ "ForEachSerial", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a34349d272182edba209e09b3de23aa63", null ],
    [ "InitializeStoreX", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#ac9586df417f7cf51d611f1eefd6c6adc", null ],
    [ "ItemInner", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a0ab36c359ba4593bf0b32aaf2432037f", null ],
    [ "Neighbour", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a76f071c929f405644acd6d8ca1d6a769", null ],
    [ "SetItem", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a5c37700c946930e06c98ef4040e7fdcd", null ],
    [ "this[HexCoords coords]", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a3f340977e93d0d597b9feea3a36b1d7c", null ],
    [ "this[IntVector2D userCoords]", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a8c2f40a0d68db8e8b83156a8e71acd7e", null ],
    [ "BackingStore", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a2c74cc607737bb77593414038fa1fd46", null ],
    [ "MapSizeHexes", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml#a39579ac1f91deab2bc2fd484f8b7cda4", null ]
];