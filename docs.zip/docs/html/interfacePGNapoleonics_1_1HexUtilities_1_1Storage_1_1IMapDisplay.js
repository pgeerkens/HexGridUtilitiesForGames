var interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay =
[
    [ "BoardHexes", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#acb29de3f73ab54b1135a6c928e227852", null ],
    [ "FovRadius", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#add6a2481d17a983e1eaed8070c61ee45", null ],
    [ "GoalHex", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#ada69c5605dcccde315ac4513152aaf4c", null ],
    [ "GridSize", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#ab6ff9f72766c9c750e63683f99091a8c", null ],
    [ "GridSizePixels", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#a45096581c4e06a3ce37e93f4732172f3", null ],
    [ "HotspotHex", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#a2c26d83fc5e2ab2732db818b1fb85723", null ],
    [ "IsTransposed", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#a9a9a66e26788d97cf577035dde0fdfbc", null ],
    [ "LandmarkToShow", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#a81c76c86f4b405d84e41f19892778e81", null ],
    [ "MapScale", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#a888bfd0c17137b45b46b55f554d13c74", null ],
    [ "MapSizeHexes", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#a64d137d7487e26e6be3a36ec1a2428c6", null ],
    [ "Name", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#add8e4634e074c0ecf786a8cbe141f434", null ],
    [ "Path", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#a98816d4a12240f712e204e631c8ebda9", null ],
    [ "StartHex", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IMapDisplay.xhtml#a6d10a5c358371835c2bce5ef0b7fbd94", null ]
];