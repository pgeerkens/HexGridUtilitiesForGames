var classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1MapDisplayExtensions =
[
    [ "CentreOfHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1MapDisplayExtensions.xhtml#aa012e07089ab0afde4ad7215db966e95", null ],
    [ "MapSizePixels< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1MapDisplayExtensions.xhtml#a55f3ad7a9bebe9304e06a9e605a08b9e", null ],
    [ "TranslateToHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1MapDisplayExtensions.xhtml#afd94a202b4b2f92a614945fa7eb44468", null ],
    [ "UpperLeftOfHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1MapDisplayExtensions.xhtml#a87993f1db03fb4e0dc40d4acaffcc095", null ]
];