var classPGNapoleonics_1_1HexUtilities_1_1Extensions =
[
    [ "InitializeDisposable< T >", "classPGNapoleonics_1_1HexUtilities_1_1Extensions.xhtml#aedf5f6678b639b5ffd046fda786cb2b1", null ],
    [ "InRange", "classPGNapoleonics_1_1HexUtilities_1_1Extensions.xhtml#a2f8fb09dd3aa3f8048f2a6d56c3def0f", null ],
    [ "IsOnboard", "classPGNapoleonics_1_1HexUtilities_1_1Extensions.xhtml#a1f0b9e6e04f00ac7e0b1608b3b6050e7", null ],
    [ "IsOnboard", "classPGNapoleonics_1_1HexUtilities_1_1Extensions.xhtml#afa57dbc51214405985b170af2d58bb69", null ],
    [ "IsOnboard", "classPGNapoleonics_1_1HexUtilities_1_1Extensions.xhtml#ac191ecc867190e53ec808e10f1a14ad6", null ],
    [ "Modulo", "classPGNapoleonics_1_1HexUtilities_1_1Extensions.xhtml#aef5d384cc4108ca0f8cbe32ede0e13c0", null ],
    [ "Range", "classPGNapoleonics_1_1HexUtilities_1_1Extensions.xhtml#a126f1dac1e3225da777c29cbfec58c27", null ]
];