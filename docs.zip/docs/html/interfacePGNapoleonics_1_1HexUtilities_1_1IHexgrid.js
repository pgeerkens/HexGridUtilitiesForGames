var interfacePGNapoleonics_1_1HexUtilities_1_1IHexgrid =
[
    [ "GridSize", "interfacePGNapoleonics_1_1HexUtilities_1_1IHexgrid.xhtml#a57ab2f9856f61beceeec8e310bf8a979", null ],
    [ "HexCorners", "interfacePGNapoleonics_1_1HexUtilities_1_1IHexgrid.xhtml#aa5bb7b30159b22f5a5aaa9ad11635bde", null ],
    [ "IsTransposed", "interfacePGNapoleonics_1_1HexUtilities_1_1IHexgrid.xhtml#a5cb6d587548ab2c8a1c779917932e1f5", null ],
    [ "Margin", "interfacePGNapoleonics_1_1HexUtilities_1_1IHexgrid.xhtml#ad43a1085dd1f98c7d1fecda271b12e3a", null ],
    [ "Scale", "interfacePGNapoleonics_1_1HexUtilities_1_1IHexgrid.xhtml#a9b621ca7a4475339d05b88ca1395438b", null ]
];