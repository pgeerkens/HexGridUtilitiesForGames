var classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions =
[
    [ "CentreOfHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml#a0357aaec551e1343b00fd5d6097c62b5", null ],
    [ "ForEachHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml#ad261afcac92cdd9f419a280e0c0b0691", null ],
    [ "GetClipInHexes< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml#abc1e1f609d17ab42997dbc6b0636d90e", null ],
    [ "MapSizePixels< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml#a5f0b755f372fc33d653bed1faef424c5", null ],
    [ "TranslateToHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml#a22e6720123a2ab3452eba4983d435842", null ],
    [ "UpperLeftOfHex< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml#a5c2165bc5b03181e70dd97c2455bec94", null ]
];