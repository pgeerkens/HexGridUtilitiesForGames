var classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap =
[
    [ "AStarBugMap", "classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap.xhtml#a5b4e8b7f8ae968464fa349c2aab80fa9", null ],
    [ "Heuristic", "classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap.xhtml#a73dacf1045ad2eba47647724ce1ed740", null ],
    [ "_board", "classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap.xhtml#aa30cd848ea62a0856b2dd739f460700f", null ],
    [ "_sizeHexes", "classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap.xhtml#ac4726a7f55c1f1581b061ba05ea62880", null ],
    [ "ElevationBase", "classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap.xhtml#a55e7faf3ca0061c875b1cba903d4d7b0", null ],
    [ "ElevationStep", "classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap.xhtml#ad1f3445c52c65f2a60545acbd993b0ba", null ],
    [ "MinimumStepCost", "classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap.xhtml#a610fead4eb25d072731bd119b632b905", null ]
];