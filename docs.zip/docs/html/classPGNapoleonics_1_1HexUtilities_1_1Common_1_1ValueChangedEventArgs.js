var classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ValueChangedEventArgs =
[
    [ "OldValue", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ValueChangedEventArgs.xhtml#a4abc37e1a09a4f91b41f4875ff3e4a95", null ],
    [ "Value", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ValueChangedEventArgs.xhtml#a435c4eee677c9bc02e8e758fedd9888c", null ]
];