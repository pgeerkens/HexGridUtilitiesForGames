var classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection =
[
    [ "ImmutableStackCollection", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml#a8705f9937f6b1644f918e7269d5c1755", null ],
    [ "ImmutableStackCollection", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml#a77488e5f9780563d160e2ff8c4fd33f7", null ],
    [ "GetEnumerator", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml#a030a08cc521cb60c5f6c3fdc45d51944", null ],
    [ "GetEnumerator", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml#abca6bf0b2010c5c97ec38e605f305d3b", null ],
    [ "Push", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml#a16e34b35e17598c634ca2c55daaec980", null ],
    [ "Remainder", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml#a81c1a8128adb03747c0ef342324a806e", null ],
    [ "TopItem", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml#ac91e74397790c83f688083a755e08173", null ]
];