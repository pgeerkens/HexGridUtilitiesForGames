var classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions =
[
    [ "Bind< TValue, TResult >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#ab56178b4aba1103bcab8353d0783e2a9", null ],
    [ "CompareTo< TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#a00797b46f8e59e2cba59a5b38c0839c8", null ],
    [ "Else< TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#abc9071a90a680949e157766a91c0daa1", null ],
    [ "ElseDefault< TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#a97943223c70cfec29396ec071e714206", null ],
    [ "ElseDo< TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#aea4d15bb7ccb56da789c09bd206f00c7", null ],
    [ "ForceGetValue< TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#a6f9c2ff4c184dad664983cd2ecd3df9f", null ],
    [ "IfHasValueDo< TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#a877b19fce7c70f6dbab8a6c4cd74adf3", null ],
    [ "Match< T, TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#ac01751dde7e1cc6af2380f68fb4c4a45", null ],
    [ "Max< TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#a2eb33f5a31112bf97fb33cc0c92909c2", null ],
    [ "Select< T, TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#a98b68b4c9454c24f99f8a24451ec0a64", null ],
    [ "SelectMany< T, TMid, TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#a670a7f0e7538da2198fa06c3baa2e815", null ],
    [ "SelectMany< T, TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#ad39ef1fbc45c379a79ab12dfbd0b9449", null ],
    [ "ToMaybe< T >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#aeef102913a7f65c2556bbd07cfaa4e16", null ],
    [ "Where< TOut >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml#a57cd078b4989a8af134d6d2b9dbaed63", null ]
];