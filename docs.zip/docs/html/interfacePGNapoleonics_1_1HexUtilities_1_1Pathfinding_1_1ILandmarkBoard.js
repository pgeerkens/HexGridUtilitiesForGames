var interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkBoard =
[
    [ "Heuristic", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkBoard.xhtml#a518047a38f037b51f05df20bb5f816df", null ],
    [ "TryEntryCost", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkBoard.xhtml#a4a5cc9b71211d0f9b8cda25a524b31cf", null ],
    [ "TryExitCost", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkBoard.xhtml#aaa2328c6c0f0d20939f5f6bf2e6b4520", null ],
    [ "Landmarks", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkBoard.xhtml#a2ebf191774e0ed3dbda0753b2bf9ca8c", null ],
    [ "MapSizeHexes", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkBoard.xhtml#a66d7a1301c81f2482b0724b7f0c5ecaf", null ]
];