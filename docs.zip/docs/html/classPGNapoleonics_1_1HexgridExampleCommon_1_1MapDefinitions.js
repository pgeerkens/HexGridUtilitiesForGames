var classPGNapoleonics_1_1HexgridExampleCommon_1_1MapDefinitions =
[
    [ "AStarBugMapDefinition", "classPGNapoleonics_1_1HexgridExampleCommon_1_1MapDefinitions.xhtml#a42014434896fd78d6b1d75b4ee6dbd16", null ],
    [ "MazeMapDefinition", "classPGNapoleonics_1_1HexgridExampleCommon_1_1MapDefinitions.xhtml#adc9ddea450f158e36774983771b1a3a0", null ],
    [ "TerrainMapDefinition", "classPGNapoleonics_1_1HexgridExampleCommon_1_1MapDefinitions.xhtml#afa8cf259ac4cbb9d25413207942b6e4f", null ]
];