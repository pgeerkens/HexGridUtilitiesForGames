var classPGNapoleonics_1_1HexUtilities_1_1Hexgrid =
[
    [ "Hexgrid", "classPGNapoleonics_1_1HexUtilities_1_1Hexgrid.xhtml#a1754e69a5419a41b68f999eec9a96000", null ],
    [ "Hexgrid", "classPGNapoleonics_1_1HexUtilities_1_1Hexgrid.xhtml#ad13d7c4b3c98a25b560e0e54ec7a0e57", null ],
    [ "GridSize", "classPGNapoleonics_1_1HexUtilities_1_1Hexgrid.xhtml#ac1131f4abace0a2159ff0b70535713d8", null ],
    [ "HexCorners", "classPGNapoleonics_1_1HexUtilities_1_1Hexgrid.xhtml#ad4ac4acaf421ed660920054f5b69bd25", null ],
    [ "IsTransposed", "classPGNapoleonics_1_1HexUtilities_1_1Hexgrid.xhtml#a3d7fe65266fa2b6e7b73763c5b41aa0b", null ],
    [ "Margin", "classPGNapoleonics_1_1HexUtilities_1_1Hexgrid.xhtml#ac86ff55151bf1c3c4adb43326bb80e38", null ],
    [ "Scale", "classPGNapoleonics_1_1HexUtilities_1_1Hexgrid.xhtml#aa0aa97b16e190060ed5e6991e53e5b50", null ]
];