var classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage =
[
    [ "BoardStorage", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a221471d003f562b7acabfe6d76fa02e5", null ],
    [ "~BoardStorage", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a6110b3edb5574d43ebf078bc28896902", null ],
    [ "Dispose", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#ae931e3379e95fa80dfb90b79dbae7b67", null ],
    [ "Dispose", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a2867e0c9f0067428396fc58424275ecb", null ],
    [ "ForAllNeighbours", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a1f9f40b03390e77ce943b179049ff813", null ],
    [ "ForAllNeighbours", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a0735035f0aee3266a08225af0ca0b78a", null ],
    [ "ForEach", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a07fb113679908495bfaffe1e0188b3f1", null ],
    [ "ForEach", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a561e3ad731de1f318d02027e12b14700", null ],
    [ "ForEach", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a2bc24a73a18ab9112979c006721dd50c", null ],
    [ "ForEach", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a5806a28bd5211a8c845ee191bb88264c", null ],
    [ "ForEachSerial", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#ac0419b96c4670c5db53f6cf666b6ca58", null ],
    [ "ForEachSerial", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#aef2f675ea83d63607e822eb0f2cf5d49", null ],
    [ "ItemInner", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#abde1d99d4498c260c88d69b5f82763aa", null ],
    [ "Neighbour", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a76f071c929f405644acd6d8ca1d6a769", null ],
    [ "SetItem", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a6aa5410c851a10bc56d4c5c5461c3806", null ],
    [ "_isDisposed", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#abd3ff179e8fafbcc6b74444a1151d5f1", null ],
    [ "this[HexCoords coords]", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a3f340977e93d0d597b9feea3a36b1d7c", null ],
    [ "this[IntVector2D userCoords]", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a8c2f40a0d68db8e8b83156a8e71acd7e", null ],
    [ "MapSizeHexes", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml#a39579ac1f91deab2bc2fd484f8b7cda4", null ]
];