var namespacePGNapoleonics_1_1HexUtilities_1_1Storage =
[
    [ "BlockedBoardStorage", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage" ],
    [ "BlockedBoardStorage32x32", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage32x32.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage32x32" ],
    [ "BoardStorage", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage" ],
    [ "FlatBoardStorage", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage" ],
    [ "IBoardStorage", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage.xhtml", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage" ]
];