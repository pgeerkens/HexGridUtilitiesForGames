var classPGNapoleonics_1_1HexgridExampleWinforms2_1_1Properties_1_1Resources =
[
    [ "Resources", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1Properties_1_1Resources.xhtml#ae0c0111a91452984e9aaf85637178d61", null ],
    [ "resourceCulture", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1Properties_1_1Resources.xhtml#ac959e883e9d6ebcf3a1bfec3051a9f22", null ],
    [ "resourceMan", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1Properties_1_1Resources.xhtml#abb8c6ed21baa0f410e749d49e46a8683", null ],
    [ "Culture", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1Properties_1_1Resources.xhtml#a0e9959e39d2c5b383729e310a6ab0479", null ],
    [ "FileExtensionMask", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1Properties_1_1Resources.xhtml#aaeaa59dc3a9b4c0fa794b960bc47c9b3", null ],
    [ "ResourceManager", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1Properties_1_1Resources.xhtml#a36cfe7a899b03cc2ba3eb46b79152215", null ]
];