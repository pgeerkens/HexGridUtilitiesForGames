var hierarchy =
[
    [ "PGNapoleonics.HexUtilities.Storage.BoardStorage< PGNapoleonics.HexUtilities.Common.Maybe< THex > >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Storage.BoardStorage< short?>", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.FastIteratorFunctor< Hexside >", "classPGNapoleonics_1_1HexUtilities_1_1FastLists_1_1FastIteratorFunctor.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.LandmarkPopulatorFunctor", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1LandmarkPopulatorFunctor.xhtml", [
        [ "PGNapoleonics.HexUtilities.Pathfinding.LandmarkPopulator", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1LandmarkPopulator.xhtml", null ]
      ] ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Storage.IBoardStorage< T >", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage.xhtml", [
      [ "PGNapoleonics.HexUtilities.Storage.BoardStorage< T >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml", [
        [ "PGNapoleonics.HexUtilities.Storage.BlockedBoardStorage< T >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage.xhtml", [
          [ "PGNapoleonics.HexUtilities.Storage.BlockedBoardStorage32x32< T >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BlockedBoardStorage32x32.xhtml", null ]
        ] ],
        [ "PGNapoleonics.HexUtilities.Storage.FlatBoardStorage< T >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1FlatBoardStorage.xhtml", null ]
      ] ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FastLists.IFastEnumerator< TItem2 >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastEnumerator.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.IFastList< ILandmark >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastList.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.ILandmarkCollection", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkCollection.xhtml", [
        [ "PGNapoleonics.HexUtilities.Pathfinding.LandmarkCollection", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1LandmarkCollection.xhtml", null ]
      ] ],
      [ "PGNapoleonics.HexUtilities.Pathfinding.LandmarkCollection", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1LandmarkCollection.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FastLists.IFastList< PGNapoleonics.HexUtilities.Pathfinding.ILandmark >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastList.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.IFastList< T >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastList.xhtml", [
      [ "PGNapoleonics.HexUtilities.FastLists.IFastListX< T >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastListX.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FastLists.IFastListX< TItem >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastListX.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.IForEachable2< T >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IForEachable2.xhtml", [
      [ "PGNapoleonics.HexUtilities.Storage.BoardStorage< T >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FastLists.IForEachable< T >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IForEachable.xhtml", [
      [ "PGNapoleonics.HexUtilities.Storage.BoardStorage< T >", "classPGNapoleonics_1_1HexUtilities_1_1Storage_1_1BoardStorage.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.IMapDisplay< IHex >", "interfacePGNapoleonics_1_1HexUtilities_1_1IMapDisplay.xhtml", [
      [ "PGNapoleonics.HexgridExampleWinforms2.IMapDisplayWpf", "interfacePGNapoleonics_1_1HexgridExampleWinforms2_1_1IMapDisplayWpf.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Common.IMapDisplayWinForms< IHex >", "interfacePGNapoleonics_1_1HexUtilities_1_1Common_1_1IMapDisplayWinForms.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IPriorityQueue< double, T >", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPriorityQueue.xhtml", [
      [ "PGNapoleonics.HexUtilities.BlueRaja.HeapPriorityQueue< T >", "classPGNapoleonics_1_1HexUtilities_1_1BlueRaja_1_1HeapPriorityQueue.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IPriorityQueue< int, PGNapoleonics.HexUtilities.HexCoords >", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPriorityQueue.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IPriorityQueue< int, TValue >", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPriorityQueue.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.HotPriorityQueue< TValue >", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1HotPriorityQueue.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IPriorityQueue< TKey, TValue >", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPriorityQueue.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.MinListHeap< TKey, TValue >", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1MinListHeap.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Common.MapDisplay< MapGridHex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplay.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.MapDisplay< PGNapoleonics.HexUtilities.IHex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplay.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.MapDisplayBlocked< Hex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayBlocked.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.MapDisplayBlocked< MapGridHex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayBlocked.xhtml", [
      [ "PGNapoleonics.HexgridExampleCommon.TerrainMap", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainMap.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Common.MapDisplayBlocked< MapHex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayBlocked.xhtml", [
      [ "PGNapoleonics.HexgridExampleCommon.AStarBugMap", "classPGNapoleonics_1_1HexgridExampleCommon_1_1AStarBugMap.xhtml", null ],
      [ "PGNapoleonics.HexgridExampleCommon.EmptyBoard", "classPGNapoleonics_1_1HexgridExampleCommon_1_1EmptyBoard.xhtml", null ],
      [ "PGNapoleonics.HexgridExampleCommon.MazeMap", "classPGNapoleonics_1_1HexgridExampleCommon_1_1MazeMap.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Common.Maybe< PGNapoleonics.HexUtilities.IHex >", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Maybe.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.Maybe< PGNapoleonics.HexUtilities.Pathfinding.IDirectedPathCollection >", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Maybe.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.Maybe< THex >", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Maybe.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleCommon.Map", "structPGNapoleonics_1_1HexgridExampleCommon_1_1Map.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleCommon.MapDefinitions", "classPGNapoleonics_1_1HexgridExampleCommon_1_1MapDefinitions.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleCommon.Properties.Resources", "classPGNapoleonics_1_1HexgridExampleCommon_1_1Properties_1_1Resources.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWinforms2.HexgridScrollViewer", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1HexgridScrollViewer.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWinforms2.MdiParent", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1MdiParent.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWinforms2.Properties.Resources", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1Properties_1_1Resources.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWinforms2.RelayCommand", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1RelayCommand.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWinforms2.TiltAwareScrollViewer", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1TiltAwareScrollViewer.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWinforms2.ViewModelBase", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1ViewModelBase.xhtml", [
      [ "PGNapoleonics.HexgridExampleWinforms2.CommandViewModel", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1CommandViewModel.xhtml", null ],
      [ "PGNapoleonics.HexgridExampleWinforms2.WorkspaceViewModel", "classPGNapoleonics_1_1HexgridExampleWinforms2_1_1WorkspaceViewModel.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexgridExampleWinforms.MdiParent", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1MdiParent.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWinforms.Properties.Resources", "classPGNapoleonics_1_1HexgridExampleWinforms_1_1Properties_1_1Resources.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWpf.App", "classPGNapoleonics_1_1HexgridExampleWpf_1_1App.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWpf.MainWindow", "classPGNapoleonics_1_1HexgridExampleWpf_1_1MainWindow.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWpf.Properties.Resources", "classPGNapoleonics_1_1HexgridExampleWpf_1_1Properties_1_1Resources.xhtml", null ],
    [ "PGNapoleonics.HexgridExampleWpf.WinForms.NativeMethods", "classPGNapoleonics_1_1HexgridExampleWpf_1_1WinForms_1_1NativeMethods.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.BitmapExtensions", "classPGNapoleonics_1_1HexgridPanel_1_1BitmapExtensions.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.GraphicsExtensions", "classPGNapoleonics_1_1HexgridPanel_1_1GraphicsExtensions.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.HexEventArgs", "classPGNapoleonics_1_1HexgridPanel_1_1HexEventArgs.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.HexgridViewModel", "classPGNapoleonics_1_1HexgridPanel_1_1HexgridViewModel.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.Layer", "classPGNapoleonics_1_1HexgridPanel_1_1Layer.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.LayerCollection", "classPGNapoleonics_1_1HexgridPanel_1_1LayerCollection.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.LayeredScrollable", "classPGNapoleonics_1_1HexgridPanel_1_1LayeredScrollable.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.Properties.Resources", "classPGNapoleonics_1_1HexgridPanel_1_1Properties_1_1Resources.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.RelayCommand", "classPGNapoleonics_1_1HexgridPanel_1_1RelayCommand.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.ViewModelBase", "classPGNapoleonics_1_1HexgridPanel_1_1ViewModelBase.xhtml", [
      [ "PGNapoleonics.HexgridPanel.CommandViewModel", "classPGNapoleonics_1_1HexgridPanel_1_1CommandViewModel.xhtml", null ],
      [ "PGNapoleonics.HexgridPanel.WorkspaceViewModel", "classPGNapoleonics_1_1HexgridPanel_1_1WorkspaceViewModel.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexgridPanel.WinForms.BufferedGraphicsExtensions", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1BufferedGraphicsExtensions.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.ControlExtensions", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1ControlExtensions.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.ExceptionDialog", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1ExceptionDialog.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.IScrollableControl", "interfacePGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1IScrollableControl.xhtml", [
      [ "PGNapoleonics.HexgridPanel.TiltAwareFlowLayoutPanel", "classPGNapoleonics_1_1HexgridPanel_1_1TiltAwareFlowLayoutPanel.xhtml", null ],
      [ "PGNapoleonics.HexgridPanel.TiltAwarePanel", "classPGNapoleonics_1_1HexgridPanel_1_1TiltAwarePanel.xhtml", null ],
      [ "PGNapoleonics.HexgridPanel.TiltAwareScrollableControl", "classPGNapoleonics_1_1HexgridPanel_1_1TiltAwareScrollableControl.xhtml", [
        [ "PGNapoleonics.HexgridPanel.HexgridPanel", "classPGNapoleonics_1_1HexgridPanel_1_1HexgridPanel.xhtml", [
          [ "PGNapoleonics.HexgridPanel.CachedMapPanel", "classPGNapoleonics_1_1HexgridPanel_1_1CachedMapPanel.xhtml", null ],
          [ "PGNapoleonics.HexgridPanel.HexgridBufferedPanel", "classPGNapoleonics_1_1HexgridPanel_1_1HexgridBufferedPanel.xhtml", null ],
          [ "PGNapoleonics.HexgridPanel.MapPanel", "classPGNapoleonics_1_1HexgridPanel_1_1MapPanel.xhtml", null ]
        ] ]
      ] ],
      [ "PGNapoleonics.HexgridPanel.WinForms.TiltAwareTreeView", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1TiltAwareTreeView.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexgridPanel.WinForms.NativeMethods", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethods.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.NativeMethodsTreeView", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1NativeMethodsTreeView.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.PaddingExtensions", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1PaddingExtensions.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.ScrollableControlExtensions", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1ScrollableControlExtensions.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.ThreadExceptionHandler", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1ThreadExceptionHandler.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.TransparentPanel", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1TransparentPanel.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.WindowsMouseInput", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1WindowsMouseInput.xhtml", null ],
    [ "PGNapoleonics.HexgridPanel.WinForms.WinFormsExtensions", "classPGNapoleonics_1_1HexgridPanel_1_1WinForms_1_1WinFormsExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.CoordsRectangle", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1CoordsRectangle.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.EnumExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EnumExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.EnumHelper", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EnumHelper.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.EnumHelper< TEnum >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EnumHelper.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.EventArgs< T >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EventArgs.xhtml", [
      [ "PGNapoleonics.HexUtilities.Common.ValueChangedEventArgs< T >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ValueChangedEventArgs.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Common.EventHandlerExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1EventHandlerExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.Extensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1Extensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.HexBoardExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexBoardExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.HexExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.HexPickingExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1HexPickingExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.IHexgridExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1IHexgridExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.ImmutableStackCollection< T >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1ImmutableStackCollection.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.IntMatrix2D", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1IntMatrix2D.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.IntVector2D", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1IntVector2D.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.IPaintableHex< TSurface, TPath >", "interfacePGNapoleonics_1_1HexUtilities_1_1Common_1_1IPaintableHex.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.Maybe< T >", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Maybe.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.MaybeExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MaybeExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.NullableExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1NullableExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.PointExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1PointExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.SizeExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1SizeExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Common.Tracing", "structPGNapoleonics_1_1HexUtilities_1_1Common_1_1Tracing.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.CustomCoords", "classPGNapoleonics_1_1HexUtilities_1_1CustomCoords.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.AbstractFastList< TItem >", "classPGNapoleonics_1_1HexUtilities_1_1FastLists_1_1AbstractFastList.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.AbstractFastList< TItem >.ClassicEnumerable< TItem2 >", "classPGNapoleonics_1_1HexUtilities_1_1FastLists_1_1AbstractFastList_1_1ClassicEnumerable.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.AbstractFastList< TItem >.FastEnumerable< TItem2 >", "classPGNapoleonics_1_1HexUtilities_1_1FastLists_1_1AbstractFastList_1_1FastEnumerable.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.FastIteratorFunctor< TItem >", "classPGNapoleonics_1_1HexUtilities_1_1FastLists_1_1FastIteratorFunctor.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.FastList< TItem >", "classPGNapoleonics_1_1HexUtilities_1_1FastLists_1_1FastList.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.FastListExtensions", "classPGNapoleonics_1_1HexUtilities_1_1FastLists_1_1FastListExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.IFastEnumerable< TItem >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastEnumerable.xhtml", [
      [ "PGNapoleonics.HexUtilities.FastLists.IFastList< TItem >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastList.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FastLists.IFastEnumerator< TItem >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastEnumerator.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FastLists.IForEachable< TItem >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IForEachable.xhtml", [
      [ "PGNapoleonics.HexUtilities.FastLists.IFastList< TItem >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastList.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FastLists.IForEachable2< TItem >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IForEachable2.xhtml", [
      [ "PGNapoleonics.HexUtilities.FastLists.IFastList< TItem >", "interfacePGNapoleonics_1_1HexUtilities_1_1FastLists_1_1IFastList.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.Dodecant", "classPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1Dodecant.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.FovBoardExtensions", "classPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1FovBoardExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.FovCone", "structPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1FovCone.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.FovConeQueue", "classPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1FovConeQueue.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.FovFactory", "classPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1FovFactory.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.IFov", "interfacePGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1IFov.xhtml", [
      [ "PGNapoleonics.HexUtilities.FieldOfView.ArrayFieldOfView", "classPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1ArrayFieldOfView.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.IFovBoard", "interfacePGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1IFovBoard.xhtml", [
      [ "PGNapoleonics.HexUtilities.Common.MapDisplay< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplay.xhtml", [
        [ "PGNapoleonics.HexUtilities.Common.MapDisplayBlocked< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayBlocked.xhtml", null ],
        [ "PGNapoleonics.HexUtilities.Common.MapDisplayFlat< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplayFlat.xhtml", null ]
      ] ],
      [ "PGNapoleonics.HexUtilities.HexBoard< THex >", "classPGNapoleonics_1_1HexUtilities_1_1HexBoard.xhtml", [
        [ "PGNapoleonics.HexUtilities.Common.MapDisplay< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplay.xhtml", null ]
      ] ]
    ] ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.RiseRun", "structPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1RiseRun.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.FieldOfView.ShadowCasting", "classPGNapoleonics_1_1HexUtilities_1_1FieldOfView_1_1ShadowCasting.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.HexCoords", "structPGNapoleonics_1_1HexUtilities_1_1HexCoords.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Hexside", "classPGNapoleonics_1_1HexUtilities_1_1Hexside.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.HexsideCosts", "classPGNapoleonics_1_1HexUtilities_1_1HexsideCosts.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.HexsidesExtensions", "classPGNapoleonics_1_1HexUtilities_1_1HexsidesExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.IHex", "interfacePGNapoleonics_1_1HexUtilities_1_1IHex.xhtml", [
      [ "PGNapoleonics.HexUtilities.Hex", "classPGNapoleonics_1_1HexUtilities_1_1Hex.xhtml", [
        [ "PGNapoleonics.HexgridExampleCommon.EmptyGridHex", "classPGNapoleonics_1_1HexgridExampleCommon_1_1EmptyGridHex.xhtml", null ],
        [ "PGNapoleonics.HexgridExampleCommon.TerrainGridHex", "classPGNapoleonics_1_1HexgridExampleCommon_1_1TerrainGridHex.xhtml", null ]
      ] ]
    ] ],
    [ "PGNapoleonics.HexUtilities.IHexBoard< out out THex >", "interfacePGNapoleonics_1_1HexUtilities_1_1IHexBoard.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.IHexgrid", "interfacePGNapoleonics_1_1HexUtilities_1_1IHexgrid.xhtml", [
      [ "PGNapoleonics.HexUtilities.Hexgrid", "classPGNapoleonics_1_1HexUtilities_1_1Hexgrid.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.IMapDisplay< THex >", "interfacePGNapoleonics_1_1HexUtilities_1_1IMapDisplay.xhtml", [
      [ "PGNapoleonics.HexUtilities.Common.IMapDisplayWinForms< THex >", "interfacePGNapoleonics_1_1HexUtilities_1_1Common_1_1IMapDisplayWinForms.xhtml", [
        [ "PGNapoleonics.HexUtilities.Common.MapDisplay< THex >", "classPGNapoleonics_1_1HexUtilities_1_1Common_1_1MapDisplay.xhtml", null ]
      ] ]
    ] ],
    [ "PGNapoleonics.HexUtilities.MapDisplayExtensions", "classPGNapoleonics_1_1HexUtilities_1_1MapDisplayExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.NeighbourCoords", "structPGNapoleonics_1_1HexUtilities_1_1NeighbourCoords.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.AltPathfinder", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1AltPathfinder.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.ConcurrentHashSet< TKey, TValue >", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ConcurrentHashSet.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.DirectedPathStepHex", "structPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1DirectedPathStepHex.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.HexKeyValuePair", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1HexKeyValuePair.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.HexKeyValuePair< TKey, TValue >", "structPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1HexKeyValuePair.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.HotPriorityQueue", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1HotPriorityQueue.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IDirectedLandmark", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IDirectedLandmark.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IDirectedPathCollection", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IDirectedPathCollection.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.DirectedPathCollection", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1DirectedPathCollection.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IHotPriorityQueueList< TKey, TValue >", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IHotPriorityQueueList.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.HotPriorityQueueList< TKey, TValue >", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1HotPriorityQueueList.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.ILandmark", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmark.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.Landmark", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1Landmark.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.ILandmarkPopulator", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkPopulator.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.LandmarkPopulatorFunctor", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1LandmarkPopulatorFunctor.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.INavigableBoard", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1INavigableBoard.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.ILandmarkBoard", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1ILandmarkBoard.xhtml", [
        [ "PGNapoleonics.HexUtilities.HexBoard< THex >", "classPGNapoleonics_1_1HexUtilities_1_1HexBoard.xhtml", null ]
      ] ],
      [ "PGNapoleonics.HexUtilities.Pathfinding.NavigableBoard", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1NavigableBoard.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IPathfinder", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathfinder.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.BidirectionalAltPathfinder", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1BidirectionalAltPathfinder.xhtml", null ],
      [ "PGNapoleonics.HexUtilities.Pathfinding.StandardPathfinder", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1StandardPathfinder.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IPathHalves", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPathHalves.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.PathHalves", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PathHalves.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.IPriorityQueue< TPriority, TValue >", "interfacePGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1IPriorityQueue.xhtml", [
      [ "PGNapoleonics.HexUtilities.Pathfinding.DictionaryPriorityQueue< TPriority, TValue >", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1DictionaryPriorityQueue.xhtml", null ]
    ] ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.PathfinderExtensions", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PathfinderExtensions.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Pathfinding.PriorityQueueFactory", "classPGNapoleonics_1_1HexUtilities_1_1Pathfinding_1_1PriorityQueueFactory.xhtml", null ],
    [ "PGNapoleonics.HexUtilities.Storage.IBoardStorage< out out T >", "interfacePGNapoleonics_1_1HexUtilities_1_1Storage_1_1IBoardStorage.xhtml", null ],
    [ "PGNapoleonics.WinForms.NativeMethods", "classPGNapoleonics_1_1WinForms_1_1NativeMethods.xhtml", null ]
];