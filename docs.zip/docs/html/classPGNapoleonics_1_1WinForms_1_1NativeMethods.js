var classPGNapoleonics_1_1WinForms_1_1NativeMethods =
[
    [ "SendMessage", "classPGNapoleonics_1_1WinForms_1_1NativeMethods.xhtml#a8ac32359c55cc5a945f053446babb842", null ],
    [ "SendMessage", "classPGNapoleonics_1_1WinForms_1_1NativeMethods.xhtml#a8ac32359c55cc5a945f053446babb842", null ],
    [ "WindowFromPoint", "classPGNapoleonics_1_1WinForms_1_1NativeMethods.xhtml#a93b314c2674ff449a5de6f3be64f25e8", null ],
    [ "WindowFromPoint", "classPGNapoleonics_1_1WinForms_1_1NativeMethods.xhtml#a93b314c2674ff449a5de6f3be64f25e8", null ]
];